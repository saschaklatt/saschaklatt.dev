# saschaklatt.dev

[![Netlify Status](https://api.netlify.com/api/v1/badges/9008f0b9-b681-42be-af32-19e2efb19170/deploy-status)](https://app.netlify.com/sites/saschaklatt/deploys)

## Project Overview

This is a modern, responsive developer portfolio template built with **Astro** and **Tailwind CSS 4**. It's designed to showcase your professional work, services, and testimonials in a clean, developer-friendly format.

### 🚀 Highlights

- **Minimal JavaScript**: Pure CSS-powered interactions like the testimonials carousel - no client-side JavaScript required to get started
- **Smart SVG System**: All illustrations and decorative elements automatically use your Tailwind color scheme through CSS custom properties
- **Performance First**: Built with Astro for optimal loading speeds and SEO
- **Accessibility Built-in**: Proper focus management, semantic HTML, and keyboard navigation support
- **Mobile-First Design**: Responsive layout that works beautifully on all devices
- **Content Collections**: Type-safe content management with Astro's content collections
- **Zero Configuration**: Works out of the box with sensible defaults

### ✨ Features

- **Fast & Modern**: Built with Astro for optimal performance and SEO
- **Responsive Design**: Mobile-first approach with Tailwind CSS 4
- **Content-Driven**: Uses Astro Content Collections for easy content management
- **Developer-Friendly**: TypeScript support, component-based architecture
- **Customizable**: Easy to personalize colors, fonts, and styling
- **SEO Optimized**: Built-in meta tags, Open Graph, and structured data
- **Performance**: Image optimization, lazy loading, and minimal bundle size

### 🏗️ Architecture

- **Framework**: Astro 5.x with TypeScript
- **Styling**: Tailwind CSS 4 with custom theme
- **Content**: JSON and Markdown files in content collections
- **Deployment**: Netlify-ready with automatic builds
- **Package Manager**: I'm using [pnpm](https://pnpm.io/) for fast, efficient dependency management

### 📁 Project Structure

```
src/
├── components/         # Reusable UI components
│   ├── sections/       # Page sections (hero, projects, etc.)
│   ├── icons/          # SVG icons and illustrations
│   └── decorations/    # Visual elements and animations
├── content/            # Content collections
│   ├── projects/       # Project showcase data
│   ├── services/       # Services offered
│   ├── testimonials/   # Client testimonials
│   └── me.json         # Personal information
├── layouts/            # Page layouts
├── pages/              # Your web pages
└── styles/             # Global styles and theme
```

## Requirements

Before you begin, ensure you have the following software installed on your system:

### Required Software

- **Node.js** 18.0.0 or higher
  - Download from [nodejs.org](https://nodejs.org/)
  - Verify installation: `node --version`
- **pnpm** (recommended) or npm/yarn/bun
  - Install pnpm: `npm install -g pnpm`
  - Verify installation: `pnpm --version`

## Getting Started

### Prerequisites

- **Node.js** 18+ 
- **pnpm** (recommended) or npm/yarn
- **Git** for version control

### Installation

1. **Install dependencies**
   ```bash
   pnpm install
   ```

2. **Start the development server**
   ```bash
   pnpm dev
   ```

3. **Open your browser**
   Navigate to `http://localhost:4321` to see your portfolio

### Customization

1. **Update personal information**
   - Edit `src/content/me.json` with your details
   - Replace `src/content/me.png` with your profile picture

2. **Add your projects**
   - Create new `.md` files in `src/content/projects/`
   - Include project images in the same directory
   - Link the image in the `.md` file with the `image` property

3. **Customize services**
   - Edit files in `src/content/services/` to match your offerings
   - The illustrations are themable SVG elements, which means they automatically use the project's color scheme. So far, we only have very few but there are more coming soon.

4. **Add testimonials**
   - Create testimonial files in `src/content/testimonials/`
   - Include client photos in the same directory

5. **Update styling**
   - Modify `src/styles/theme.css` for colors and fonts
   - Customize Tailwind config for additional theming

### Building for Production

```bash
# Build the site
pnpm build

# Preview the production build
pnpm start
```

The built site will be in the `dist/` directory, ready for deployment.

## Customizing the Color Scheme

The portfolio uses a sophisticated color system built on Tailwind CSS 4's theme configuration. All colors are defined in `src/styles/theme.css` using CSS custom properties.

### Current Color Palette

The template includes four main color categories:
- **Primary** (`--color-primary-*`): Main brand color (currently a vibrant cyan)
- **Accent** (`--color-accent-*`): Highlight color for CTAs and important elements (currently pink)
- **Neutral** (`--color-neutral-*`): Text, backgrounds, and UI elements (currently blue-gray)
- **Secondary** (`--color-secondary-*`): Supporting color for gradients and accents (currently yellow)

### How to Change Colors

1. **Edit the theme file**: Open `src/styles/theme.css`
2. **Update color values**: Replace the hex values in the `--color-*` variables
3. **Use color tools**: Tools like [Coolors](https://coolors.co/) or [Color Hunt](https://colorhunt.co/) can help generate harmonious palettes
4. **Generate Tailwind shades**: Use tools like [Tailwind Shades](https://www.tailwindshades.com/) to automatically generate the full range of color shades (50-950) from a single base color
5. **Test your changes**: The changes will automatically apply to all components, including SVGs

### Example: Changing the Primary Color

```css
/* In src/styles/theme.css */
@theme {
    --color-primary: #3b82f6; /* Change from cyan to blue */
    --color-primary-50: #eff6ff;
    --color-primary-100: #dbeafe;
    /* ... continue with other shades */
}
```

### Smart SVG Integration

All illustrations and decorative elements (like the heart background in testimonials) automatically inherit your color scheme. They use Tailwind's `theme()` function to reference your custom colors:

```svg
<path class="[fill:theme(colors.accent.600)]" />
```

This means you only need to change colors in one place, and everything updates automatically!

### Coming Soon: Predefined Color Schemes

We're planning to add a collection of beautiful, pre-designed color schemes that you can choose from. These will include:
- Professional corporate themes
- Creative and vibrant palettes
- Minimalist monochrome options
- Light/dark mode variations

## Commands

All commands are run from the root of the project, from a terminal:

| Command                   | Action                                               |
| :------------------------ | :--------------------------------------------------- |
| `pnpm install`            | Installs dependencies                                |
| `pnpm dev`                | Starts local dev server at `localhost:4321`          |
| `pnpm build`              | Build your production site to `./dist/`              |
| `pnpm start`              | Runs your locally build (requires `pnpm build`)      |
| `pnpm astro ...`          | Run CLI commands like `astro add`, `astro check`     |
| `pnpm astro -- --help`    | Get help using the Astro CLI                         |

## Caveats

- Astro components can't be used inside a framework component like React components
- Storybook can't render Astro components
