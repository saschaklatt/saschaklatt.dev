export type IconId = "document" | "envelope" | "github" | "instagram" | "linkedin" | "nomadlist" | "stackoverflow" | "x" | "xing";

export enum IllustrationId {
    ApiCloudScreen = "api-cloud-screen",
    HeadlessCms = "headless-cms",
    Mongodb = "mongodb",
    RocketCloud = "rocket-cloud",
    UiComponentsPhone = "ui-components-phone",
}

export interface EditorTab {
    id: string;
    tab: string;
    lines: string[];
}

export interface CtaProps {
    href: string;
    text: string;
    target?: string;
    rel?: string;
    class?: string;
}
