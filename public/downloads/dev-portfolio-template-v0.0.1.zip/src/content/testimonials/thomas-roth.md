---
id: thomas-roth
order: 0
referrer: Thomas Roth
referrerRole: Head Of Development
referrerCompany: MAHENA - marketing.services.kommunikation
referrerImage: ./thomas-roth.webp
---

Sascha is one of those rare people you just don't come across often – genuinely kind, rock-solid, and 100% trustworthy. We've been working together for years on Landbot and Ninox projects, and he always delivers: fast, pragmatic, and solid. Low-code wasn't his thing at first, but now he's really got the hang of it. Would we recommend him? Only if we have to – we'd rather keep him to ourselves.
