---
id: murat-kemaldar
order: 3
referrer: Murat Kemaldar
referrerRole: Front-end Developer
referrerCompany: Freelancer
referrerImage: ./murat-kemaldar.webp
---

Sascha is one of the few developers I've stayed in touch with as a freelancer, and also (consciously) worked together on several projects. He not only has high quality standards, he also has the right interpersonal skills that make him a well-balanced teammate that I enjoy working with. Sascha is playful, curious, and not afraid to dive into new technologies and trends that are outside his comfort zone.
