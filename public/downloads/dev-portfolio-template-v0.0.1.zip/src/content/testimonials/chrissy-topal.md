---
id: chrissy-topal
order: 4
referrer: Chrissy Topal
referrerRole: Front-end Developer
referrerCompany: Freelancer
referrerImage: ./chrissy-topal.webp
---

Sascha is a first-class developer. His social skills made the collaboration in the team very pleasant. Together we worked on the relaunch of the jobvalley website. With his expertise, we created a very modern and clean codebase that is fun to work in. If I could put together a dev team in the future, Sascha would definitely be part of it.
