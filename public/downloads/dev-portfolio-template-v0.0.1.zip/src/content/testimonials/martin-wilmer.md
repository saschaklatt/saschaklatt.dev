---
id: martin-wilmer
order: 5
referrer: Martin Wilmer
referrerRole: Managing Director
referrerCompany: robole - Kabisch & Wilmer GbR
referrerImage: ./martin-wilmer.webp
---

Sascha has been developing sophisticated full-stack solutions with us for several years. His way of working is characterised by the highest quality, adherence to deadlines and professional and friendly communication. We are happy to have such a talented and reliable developer in our network.
