---
id: felix-wolf
order: 1
referrer: Felix Wolf
referrerRole: Online Marketing Manager
referrerCompany: Studitemps GmbH
referrerImage: ./felix-wolf.webp
---

Sascha supported us with the relaunch of our corporate website jobvalley.com. We benefited greatly from his broad and deep expertise in front-end and back-end development, as well as in UX/UI. Thanks to his wealth of experience, he was always able to find a suitable solution even for complex problems. With his friendly and professional manner, he quickly integrated himself into the project team. We could rely on him 100% and I would be very happy to work with him again.
