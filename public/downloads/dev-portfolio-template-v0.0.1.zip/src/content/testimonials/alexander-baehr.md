---
id: alexander-baehr
order: 2
referrer: Alexander Baehr
referrerRole: Team Lead Front-end
referrerCompany: Invia Flights Germany GmbH
referrerImage: ./alexander-baehr.webp
---

Sascha has a deep understanding of software development and was quickly able to unfold his solid tech expertise in our complex architecture. He has always been a thoughtful, insightful, motivated developer and his passion and enthusiasm for development helped our team evolve further to create more efficient solutions to lift our projects to the next level.
